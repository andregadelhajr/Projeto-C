main()
{
	float valor_porc, porc;
	
	printf ("Porcentagem que se deja adiquirir: ");
	scanf ("%f", &valor_porc);
	
	porc = 555 * (valor_porc / 100);
	
	printf ("\nA porcentagem do valor 555 por %f porcento= %f\n",valor_porc, porc);

}
