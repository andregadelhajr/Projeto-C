main(){
	
	char caracter;
	
	printf("Digite um caracter: ");
	scanf("%c", &caracter);
	
	printf("\nCaracter: %c\n", caracter);
	printf("Decimal: %d\n", caracter);
	printf("Octal: %o\n", caracter);
	printf("Hexadecimal: %x\n", caracter);
}
