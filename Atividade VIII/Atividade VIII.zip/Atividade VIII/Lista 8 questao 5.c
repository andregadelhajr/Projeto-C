main(){
	printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
	printf("\t\t\xBA        \xBA\n");
	printf("\t\t\xBA        \xBA\n");
	printf("\t\t\xBA        \xBA\n");
	printf("\t\t\xBA        \xBA\n");
	printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n");
}
