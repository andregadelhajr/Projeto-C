
main()
{
	int opcao;
	printf(" Escolha uma regi�o do Brasil que gostaria de conhecer");
	printf("\n=======================================================\n");
	
	
    printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
    printf("\t\t\xBA                     \xBA\n");
    printf("\t\t\xBA                     \xBA\n");
	printf("\t\t\xBA   Menu de Opcao     \xBA\n");
	printf("\t\t\xBA  ================   \xBA\n");
    printf("\t\t\xBA    1. Norte         \xBA\n");
	printf("\t\t\xBA    2. Nordeste      \xBA\n");
	printf("\t\t\xBA    3. Centro-Oeste  \xBA\n");
    printf("\t\t\xBA    4. Sul           \xBA\n");
	printf("\t\t\xBA    5. Sudeste       \xBA\n");	
	printf("\t\t\xBA                     \xBA\n");
	printf("\t\t\xBA                     \xBA\n");
	printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");

	
	printf("=======================================================\n");
	printf ("                        Opcao: ");	
	scanf ("%i", &opcao);
	
	
	switch(opcao)
	{
		case 1:
			system("cls");
			printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA  Opcao selecionada: \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA       Norte         \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");
			break;
		case 2:
			system("cls");
		    printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA  Opcao selecionada: \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA      Norteste       \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");
			break;
		case 3:
			system("cls");
			printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA  Opcao selecionada: \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA    Centro-Oeste     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");
			break;
		case 4:
			system("cls");
			printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA  Opcao selecionada: \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA         Sul         \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");
			break;
		case 5:
			system("cls");
			printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA  Opcao selecionada: \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA       Sudeste       \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");
			break;
		case 0:
			system("cls");
		    printf("\n\n\n\n\t\t\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n");
        	printf("\t\t\xBA                     \xBA\n");
        	printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
            printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA      encerrado      \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xBA                     \xBA\n");	
	        printf("\t\t\xBA                     \xBA\n");
	        printf("\t\t\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n\n\n");	
			break;
		default:
		    system("cls");
			printf("\n\n\n\n\n\n\t\t\t\t\t\tErro, tente novamente.\t\t\t\t\t\t\n\n\n\n\n\n");
			break;
	}
}
