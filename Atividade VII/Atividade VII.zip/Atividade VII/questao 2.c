main(){
	float raio;
	
	printf ("Digite o raio da circufencia para calcular a area: ");
	scanf ("%f", &raio);
	
	printf ("\nA area do circuferencia e: %f", (3.14 * (raio * raio)));
	
}
